#!/bin/bash

# ==========================================================
# 1. OPCIÓN DE AYUDA (-help / --help)
# ==========================================================
if [[ "$1" == "-help" ]] || [[ "$1" == "--help" ]]; then
	echo "==============================================================="
	echo "AYUDA - SCRIPT DE RESPALDO (backup_full.sh)"
	echo "==============================================================="
	echo "Uso: $0 <origen> <destino>"
	echo "Descripción: Realiza un respaldo comprimido (.tar.gz) del origen"
	echo "		especificado y lo almacena en el destino indicado"
	echo "		añadiendo la fecha en formato ANSI (YYYYMMDD)."
	echo "Ejemplo: $0 /var/logs /backup_dir"
	echo "==============================================================="
	exit 0
fi

# ==========================================================
# 2. VALIDACIÓN DE ARGUMENTOS (Exactamente 2 requeridos)
# ==========================================================
if [ $# -ne 2 ]; then
	echo "Error: Cantidad de argumentos incorrecta."
	echo "Uso correcto: $0 <origen> <destino>"
	echo "Ejecute '$0 -help o --help' para obtener asistencia."
	exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# ==========================================================
# 3. VALIDACIÓN DE DISPONIBILIDAD DE LOS SISTEMAS DE ARCHIVOS
# ==========================================================
if [ ! -e "$ORIGEN" ]; then
    echo "Error crítico: El origen '$ORIGEN' no existe o no está disponible."
    exit 2
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error crítico: El directorio de destino '$DESTINO' no existe o no se encuentra montado."
    exit 3
fi

# ==========================================================
# 4. PROCESAMIENTO DE FECHA Y NOMBRE DE ARCHIVO
# ==========================================================
FECHA=$(date +%Y%m%d)
NOMBRE_BASE=$(basename "$ORIGEN")

if [[ "$NOMBRE_BASE" == "logs" ]]; then
    ARCHIVO_BKP="logs_bkp_${FECHA}.tar.gz"
else
    ARCHIVO_BKP="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"
fi

# ==========================================================
# 5. EJECUCIÓN DEL RESPALDO COMPRIMIDO (.tar.gz)
# ==========================================================
tar -czf "$DESTINO/$ARCHIVO_BKP" "$ORIGEN" 2>/dev/null

if [ $? -eq 0 ]; then
    echo "Éxito: Respaldo de '$ORIGEN' guardado correctamente en '$DESTINO/$ARCHIVO_BKP'."
    exit 0
else
    echo "Error: Falló el proceso de compresión y respaldo."
    exit 4
fi
